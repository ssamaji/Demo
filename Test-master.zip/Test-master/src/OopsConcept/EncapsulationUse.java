package OopsConcept;

public class EncapsulationUse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Encapsulation en=new Encapsulation();
		en.setName("ashiwani");
		System.out.println(en.getName());

	}

}
