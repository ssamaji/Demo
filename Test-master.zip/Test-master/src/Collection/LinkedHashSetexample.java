/*
 * Contains unique elements only like HashSet.
 * It extends HashSet class and implements Set interface.
 * Insertion order is preserved.
 * Permit null value
 */
package Collection;
import java.util.*;  
class LinkedHashSetexample
{  
 public static void main(String args[])
 {  
   
  LinkedHashSet<String> al=new LinkedHashSet<String>();  
  al.add("Ravi");  
  al.add("Vijay");  
  al.add("Ravi");  
  al.add("Ajay");  
  
  Iterator<String> itr=al.iterator();  
  while(itr.hasNext())
  {  
   System.out.println(itr.next());  
  }  
 }  
}  