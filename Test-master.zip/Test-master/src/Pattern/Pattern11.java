package Pattern;
class Pattern11
{
	public static void main(String...s)
	{
	int n=2;
	for(int i=1;i<10;i++)
	{
		int mul=n*i;
	   System.out.println(n+" "+ "*"+ " "+i+" "+"="+" "+mul);
	}
	}
}