package Pattern;
class AllCombination
{
	public static void main(String...s)
	{

char ch1,ch2,ch3;
for(ch1='A';ch1<='C';ch1++)
{
	for(ch2='A';ch2<='C';ch2++)
{
	
for(ch3='A';ch3<='C';ch3++)
{
	
System.out.println(ch1+ " " +ch2+ " " +ch3);
}

}
}





	}
}