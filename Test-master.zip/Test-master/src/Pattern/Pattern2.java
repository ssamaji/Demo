package Pattern;
class Pattern2
{
	public static void main(String...s1)
	{
	 
	 for(int i=5;i>0;i--)
	 {
	    for(int j=1;j<=i;j++)
	    {
	      System.out.print("j");
	    }
     System.out.println();

	 }
	}
}



/*
12345
1234
123
12
1
*/