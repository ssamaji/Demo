package Number;
class Maxwithoutif2
{
	
	void max(int x,int y)
	{

	System.out.print((x>y)?x:y);

	}

public static void main(String...s)
{
	Maxwithoutif2 m=new Maxwithoutif2();
	m.max(2,5);
}

}


