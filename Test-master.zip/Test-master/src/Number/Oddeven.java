package Number;
class Oddeven
{
	public static void main(String...s)
	{
          int n=51;
          if((n&1)==0)
          System.out.print("even");
          else
          System.out.print("odd");


	}
}