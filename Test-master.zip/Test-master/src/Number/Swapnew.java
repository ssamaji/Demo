package Number;
class Swapnew
{

   public static void main(String...s)
   {
	
	int a=5,b=6;
	a=(b-a)+(b=a);
	/*
	a=a+b;
	b=a-b;
	a=a-b;
	
	a=a^b;
	b=a^b;
	a=a^b;
	
	a=a*b;
	b=a/b;
	a=a/b;
	
	*/
	
	
	System.out.println(a);
	System.out.println(b);
}


}