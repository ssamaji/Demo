class Test
{
	public static void main(String...s)
	{
	int a=07;
	System.out.print(a);

	}
}