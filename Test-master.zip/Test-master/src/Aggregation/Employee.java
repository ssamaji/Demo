//package Aggregation;
//class Address
//{ 
//	void display()
//	{
//	
//	String city="Patna";
//	int pin=80001;
//	System.out.println(city);
//	System.out.println(pin);
//    }
//
//}
//class Employee
//{
//	Address ad;//aggregation
//	int age=10;
//	int mobile=1234;
//	void show()
//	{
//	System.out.println(mobile);
//	System.out.println(age);
//	}
//
//	ad=new Address();
//	ad.display();
// public static void main(String ...s)
// {
//   Employee e=new Employee();
//   e.show();
//
// }
//}
//}