package Math;
import java.math.*;
class A
{
public static void main(String...s)
{
	
	BigInteger b1,b2,b3;
	b1=new BigInteger("126867766767868868668668998997787886768666757644545545455");
	b2=new BigInteger("66676666768655454545455454");
	b3=b1.multiply(b2);//we can use add,subtract,divide,max,min,not,and,remainder and many more.......
	//String s1=b3.toString();
	System.out.print(b3);
}
	

}