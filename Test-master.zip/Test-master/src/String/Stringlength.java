package String;

public class Stringlength {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		String s="hello";
		int count=0;
		for(char ch:s.toCharArray())
			count++;
		System.out.println(count);
		//System.out.println(ch);

	}

}
