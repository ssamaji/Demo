package String;
class Stringreplace
{
	
	public static void main(String...s)
	{

	String s1="ram is good boy";
	String s2=s1.replace('o','x');
	System.out.println(s2);
	}
}