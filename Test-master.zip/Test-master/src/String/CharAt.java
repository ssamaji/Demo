
package String;//java string charAt() method returns a char value at the given index number
class CharAt
{
	public static void main(String...s)
	{

     String su="Hello";
	 char ch=su.charAt(4);
     System.out.print(ch);
	}
}