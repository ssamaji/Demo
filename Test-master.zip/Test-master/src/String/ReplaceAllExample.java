package String;
//remove all space

class ReplaceAllExample
{  
public static void main(String args[])
{  
String s1="My name is Khan. My name is Bob. My name is Sonoo.";  
String replaceString=s1.replaceAll(" ","");//replaceAll("\\s","");  
System.out.println(replaceString);  
}}  