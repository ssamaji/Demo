package String;
class Stringbufferrevesre
{
	public static void main(String...s)
	{
	  StringBuffer sb=new StringBuffer("hello");
	  sb.reverse();
	  System.out.println(sb);
	}
}