
public class testmethod {

	static void testmethod()
	{
		System.out.println("hello");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		testmethod.testmethod();
		
	}

}
