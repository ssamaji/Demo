package Array;

import java.util.Date;

public class Sort {

	public static void main(String...s)
	{
		Date d=new Date();
		System.out.println(d);
	}
}
