package Array;

public class Duplicateinarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]={1,1,4,3,4,11,44};
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]==a[j] && i!=j)
				{
					System.out.println(a[i]);
					break;
					
				}
			}
		}
		

	}

}
