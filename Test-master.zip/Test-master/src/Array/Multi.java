package Array;
class Multi
{
	public static void main(String...s)

	{

int a=Integer.parseInt(s[0]);
int b=Integer.parseInt(s[1]);
int mul=0;

for(int i=1;i<=b;i++)
{
	
	mul=mul+a;

} 

System.out.println(mul);

}


}
