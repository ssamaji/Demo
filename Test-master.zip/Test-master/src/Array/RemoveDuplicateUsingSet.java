package Array;

import java.util.HashSet;

public class RemoveDuplicateUsingSet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]={1,4,533,3,1,4,4,4,41,11,1};
		HashSet<Integer> hs=new HashSet<Integer>();
		for(int i=0;i<arr.length;i++)
			//hs.add(new Integer(arr[i]));
		hs.add(arr[i]);
		System.out.println(hs);
		

	}

}
