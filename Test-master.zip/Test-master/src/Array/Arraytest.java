package Array;
class Arraytest
{
	public static void main(String...s)
	{
	int a[]={1,4,2};
	System.out.println(a[4]);// array index out of bound exception
	}
}