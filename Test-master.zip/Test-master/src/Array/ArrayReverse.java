package Array;
class ArrayReverse
{
	
   public static void main(String...s)
   {
   	
   int [] a={1,9,3,4,5,2,7};

  for(int i=a.length-1;i>=0;i--)

  System.out.println(a[i]);
   }
}