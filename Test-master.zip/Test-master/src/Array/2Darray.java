package Array;
class TestArray3
{
	public static void main(String...s)
	{

int a[][]={{1,2,3},{2,3,4},{9,8,5}};
for(int i=0;i<a.length;i++)
{
	for(int j=0;j<a.length;j++)
	{
		System.out.print(a[i][j] + " "  );

	}
	System.out.println();
}

    }

}