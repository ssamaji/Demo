package Conversion;

public class D2BCoversionByMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int decimal=1000;
		System.out.println(Integer.toBinaryString(decimal));
	}

}
