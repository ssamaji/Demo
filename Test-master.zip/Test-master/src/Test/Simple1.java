package Test;
class Simple1
{  
 public static void main(String args[])
 {  
 Simple1 s=new Simple1();  
 System.out.println(s instanceof Object);//true  
 }  
}  
