package Newfeature;
import static java.lang.System.*;    
class StaticImportExample
{
  public static void main(String args[])
  {  
   out.println("Hello");//Now no need of System.out  
   out.println("Java");  
  
 }   
}  
/**
 * JAVA -  5
 */
   