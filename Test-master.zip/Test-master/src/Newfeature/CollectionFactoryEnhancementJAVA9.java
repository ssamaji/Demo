package Newfeature;

import java.util.List;
public class CollectionFactoryEnhancementJAVA9 {
	
	    public static void main(String[] args) {  
	    	
//	        List<String> list = List.of("Java","JavaFX","Spring","Hibernate","JSP");  
//	        for(String l:list) {  
//	            System.out.println(l);  
//	        }  
	    	
	    	/*From Java 9 release, underscore is a keyword and can't be used as an identifier or variable name */
//	    	int _=12;
//	    	System.out.println(_);
	    	
	    	
	    }  
	}  
