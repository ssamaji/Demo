package Newfeature;
class UnboxingExample1
{  
  public static void main(String args[])
  {  
    Integer i=new Integer(50);  
        int a=i;  
          
        System.out.println(a);  
 }   
}  