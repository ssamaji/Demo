//A lambda expression is an anonymous function (not 100% true for Java but lets assume it for time being). 
//Simply put, it's a method without a declaration, i.e., access modifier, return value declaration, and name
/*
package Newfeature;
class Lambda
{
	(int a)->
	{
	System.out.println(a);
	}

public static void main(String...s)
{
	Lambda l=new Lambda();
	l.(20);
}

}

*/

