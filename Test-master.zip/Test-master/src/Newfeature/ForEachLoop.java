package Newfeature;
class ForEachLoop
{
	public static void main(String...s)
	{
	   int a[]={23,11,123,10};
	   for(int a1:a)
	   System.out.println(a1);
	}
}