package Logical;

public class Series {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * int i,j;
        for(i=0;i=1;j--)
        printf("%d",j);
        return 0;
		 */

		int i,j;
//		for(int i=0;i=1;j--)
//			System.out.printf("%d",j);
	}

}
