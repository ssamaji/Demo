package Casting;
class Stringtointviceversa
{
	
	public static void main(String...s)
	{
           String s1="12345";
           int a=Integer.valueOf(s1);
           System.out.println("VALUE OF STRING IN INT  "+a);
        
           int a1=1245;
           String s2=String.valueOf(a1);
           System.out.println("Value of int into string  "+s2);
      

          	}
}